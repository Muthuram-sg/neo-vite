import React from 'react';
import './button.scss'; 
import { makeStyles } from '@material-ui/core/styles';
import clsx from  'clsx';
function Button(props){  
    const useStyles = makeStyles((theme) => ({
        text:{ 
            height: '24px',
            fontFamily: 'Inter',
            fontStyle: 'normal',
            fontWeight: 500,
            fontSize: '14px',
            lineHeight: '24px', 
            display: 'flex',
            alignItems: 'center',  
            flex: 'none',
            order: 0,
            flexGrow: 0
        },
        root:{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            padding: '8px 14px',
            gap: 5,
            minWidth: 67,
            borderRadius: 4,
            cursor: 'pointer',
        },
        primaryRoot:{ 
            background: props.danger?'#DA1E28':'#0F6FFF',
            color: '#FFFFFF',
            border: 0,  
            '&:hover':{
                background: props.danger?'#BE1B22':'#0C5EE0 !important',
            },
            '&:active':{
                background: props.danger?'#A2171D':'#0A50BF !important'
            }
        },
        secondaryRoot:{
            background: '#F4F4F4',
            color: "#525252",
            borderRadius: 4,
            border: '1px solid #6F6F6F',
            '&:hover':{
                background: '#E5E5E5 !important'
            },
            '&:active':{
                background: '#6F6F6F !important'
            }
        },
        tertiaryRoot:{ 
            background: 'transparent',
            color: props.danger?'#DA1E28':"#0F6FFF", 
            border: props.danger?'1px solid #DA1E28':'1px solid #0F6FFF',  
            '&:hover':{
                background: props.danger?'#BE1B22 !important':'#0C5EE0 !important',
                color: "#FFFFFF !important"
            },
            '&:active':{  
                background: props.danger?'#A2171D !important':'#0A50BF !important',
                color: "#FFFFFF !important"
            }
        },
        ghostRoot:{ 
            background: 'transparent',
            color: props.danger?"#DA1E28":"#0F6FFF",
            border: 0,
            borderRadius: 4,  
            '&:hover':{
                color:props.danger? "#fff":'#0F6FFF',
                background: props.danger?'#BE1B22':'#E5E5E5' 
            },
            '&:active':{  
                color:props.danger? "#fff":'#0F6FFF',
                background: props.danger?'#A2171D':'#C6C6C6', 
            }
        },
        disabledPrimary:{
            opacity: 0.3
        },
        disabledSecondary:{
            border: '1px solid #525252 !important',
            background: 'transparent',
            color: '#525252 !important'
        },
        disabledTertiary:{
            background: 'transparent',
            border: '1px soldi #0F6FFF',
            color: '#0F6FFF !important'
        }, 
        disabledRoot:{ 
            border: 0,
            background: '#86B6FE !important',
        },        
        disabledTertiaryRoot:{ 
            border: '1px solid #969696 !important',
            background: '#FFFFFF !important'
        },
        textDisabled:{
            color: '#585757 !important'
        },
        icon:{
            width: 16
        },
        size:{    
            height: 40  
        },
        noWidth:{
            minWidth: 40
        }
    }))
    const classes = useStyles();
    return (
        // <button onClick={props.onClick} className={classes.primaryRoot+`primary-root ${props.responsive?'responsive':''} ${props.lg?'lg':props.sm?'sm':'md'} ${props.disabled?" primary-disabled":""}`} style={props.style}>
        <button onClick={!props.loading && !props.disabled?props.onClick:{}} 
            className={
                clsx(
                        classes.root,
                        props.type === 'danger'?classes.dangerRoot:props.type === 'ghost'?classes.ghostRoot:props.type==='secondary'?classes.secondaryRoot:props.type==='tertiary'?classes.tertiaryRoot: classes.primaryRoot, 
                        classes.size,
                        props.disabled? classes.disabledPrimary:"",
                        !props.value || props.value===""? classes.noWidth:""
                    )
                } 
            style={props.style}  
        >             
            {
                props.value?(
                    <span className={clsx(classes.text)}>{!props.loading?props.value?props.value:"Button":"Loading..."}</span>
                ):(
                    <React.Fragment></React.Fragment>
                )        
            }                
            {
                props.icon && !props.loading?<props.icon className={classes.icon} stroke={props.type==='primary'?"#FFF":props.type==='secondary'?"#575757":"#0F6FFF"}/>:<React.Fragment></React.Fragment>
            }            
        </button>
    )
}
// const isNotRender = (prev,next)=>{
//     return prev.loading !== next.loading? false:true;
// }
// export default React.memo(Button,isNotRender);
export default Button;