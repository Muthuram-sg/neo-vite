import React from "react"; 
import Switch from '@material-ui/core/Switch';
import { withStyles,makeStyles,FormControlLabel,Checkbox} from '@material-ui/core'; 
import { useTranslation } from 'react-i18next'; 
import clsx from  'clsx'; 

export default function CustomSwitch(props) { 
    const { t } = useTranslation(); 
    const SwitchCustom = withStyles((theme) => ({
        root: {
            width: props.size === "small" ? 26.32 : 39.5,
            height: props.size === "small" ? 16 : 24,
            padding: 0,
            display: 'flex', 
        },
        switchBase: {
            padding: 2,
            color: theme.palette.common.white,
            left: props.size === "small" ? "0px" : "1px",
            top: props.size === "small" ? "-0.5px" : "0px",
            '&$checked': {
                transform: 'translateX(12px)',
                color: theme.palette.common.white,
                left: props.size === "small" ? "-2px" : "2.5px",
                top: props.size === "small" ? "-1px" : "0px",
                '& + $track': {
                    opacity: 1,
                    backgroundColor: props.disabled ?  "#CFE4FC" : theme.palette.primary.main ,
                    borderColor: props.disabled ?  "#CFE4FC" : theme.palette.primary.main,
                },
            },
        },
        thumb: {
            width: props.size === "small" ? 13.33 : 20,
            height: props.size === "small" ? 13.33 : 20,
            boxShadow: 'none',
        },
        track: {
            border: `1px solid ${theme.palette.grey[500]}`,
            borderRadius: props.size === "small" ? 16 / 2 : 40 / 2,
            opacity: 1,
            backgroundColor: props.disabled ?  "#CFE4FC" : (props.secondaryLabel ? theme.palette.primary.main : theme.palette.grey[500]),
        },
        checked: {},
    }))(Switch); 
    const useStyles = makeStyles((theme) => ({
        text:{ 
            fontSize: "0.75rem",fontFamily: "Inter, sans-serif",fontWeight: "400",lineHeight: '1.66',whiteSpace:"nowrap",display: 'flex',alignItems: 'center',
            padding: "0 5px"
        },
        checkbox:{
            marginLeft: "10px"
        },
        switchroot:{
            display:'inline-flex',alignItems:'center'
        }
    }))
    const classes = useStyles();
    return (
        <div className={classes.switchroot}>
            {props.switch ?
            <React.Fragment>
                {props.primaryLabel &&
                <span className={classes.text}>
                    {t(props.primaryLabel)}
                </span>}
                <div>
                        <SwitchCustom checked={props.checked ? props.checked : false} onChange={props.onChange} name="checkedC" id='switch' 
                        disabled={props.disabled ? props.disabled : false}/>
                </div>
                {props.secondaryLabel &&
                <span className={classes.text}>
                    {t(props.secondaryLabel)}
                </span>}
            </React.Fragment>
            :
            <FormControlLabel
                control={
                  <Checkbox
                    id='checkbox'
                    checked={props.checked ? props.checked : false}
                    onChange={props.onChange}
                    name="incomingWH"
                    color="primary"
                    disabled={props.disabled ? props.disabled : false}
                  />
                }
                label={<span className={classes.text}>
                  {t(props.primaryLabel ? props.primaryLabel : '')}</span>}
                className={clsx(classes.checkbox,props.className ? props.className : '')} 
              />
            }
        </div>
    );
} 