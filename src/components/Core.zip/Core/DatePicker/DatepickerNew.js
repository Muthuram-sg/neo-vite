import React, { useState} from "react";
//import { MuiPickersUtilsProvider,KeyboardDateTimePicker} from '@material-ui/pickers';
import { Grid } from '@material-ui/core';
import IOTMenuItem from '../../ui/menuItem'
import { useTranslation } from 'react-i18next';
//import DateFnsUtils from '@date-io/date-fns';
import MenuItem from "../../ui/menuItem"
import {  makeStyles } from '@material-ui/core/styles';
import Starttime from 'components/Core/DatePicker/components/DatepickerStart'
import Endtime from 'components/Core/DatePicker/components/DatepickerEnd'

export default function Dashboard(props) {
    const { t } = useTranslation();
    const [,setSelectedvals] = useState(null);  
    const clickedGroupButton=(e)=>{
      let c;
      if(props.Dropdowndefine==="Explorer"){
        if( e.target.value===18){
          c="Last 24 Hrs"
        }else if( e.target.value===1){
          c="Last Hour"
        }else if( e.target.value===12){
          c='Last 3 Hrs'
        }else if( e.target.value===6){
          c="Today"
        }else if( e.target.value===13){
          c='Current Shift'
        }else if( e.target.value===14){
          c='Last 7 Days'
        }else if( e.target.value===7){
          c="Yesterday"
        }else if( e.target.value===8){
          c='ThisWeek'
        }else if( e.target.value===9){
          c='ThisMonth'
        }else if( e.target.value===15){
          c='Last 30 days'
        }else if( e.target.value===16){
          c='LastMonth'
        }else if( e.target.value===17){
          c="Custom"
        }       
        props.clickedfns(c)
      }else{
        setSelectedvals(Number(e.target.value))
        props.clickedfns(e)
      }
    }   
    const useStyles = makeStyles((theme) => ({
      slectbtnbox:{
        gap:10,
        fontSize: "16px",
        borderBottom: `0px solid ${theme.colorPalette.divider}`,
        borderRight: `1px solid ${theme.colorPalette.divider}`,
        '&:hover': {
            borderRadius: 4,
        },
        
      },
      selectboxmain:{
        backgroundColor: "#fcfcfc",
        zIndex:"99",
        position:"fixed",
        boxShadow: "0px 5px 5px -3px rgb(0 0 0 / 20%), 0px 8px 10px 1px rgb(0 0 0 / 14%), 0px 3px 14px 2px rgb(0 0 0 / 12%)",
        borderRadius:"4px"
      },
      selectboxDesign:{        
        right:10,        
        marginTop:"58px",
        height:"317px",       
      },selectboxDesign1:{        
        width:"24%" 
      },
      selectboxexp1:{        
        marginTop:"52px",
        width: "57%",
        height:"213px",
        right:14,
      },
      selectboxexp2:{             
        marginTop:"51px",
        width: "20%",
        height:"203px",
        right:50,
        
      },
      slectboxreport1:{
        marginTop:"52px",
        width: "47%",
        height:"303px",
        right:0,
       
      }, 
      slectboxreport2:{
        marginTop:"53px",
        width: "23%",
        height:"308px",
        right:81,
        },
        slectboxall:{
        padding: "5px",
        marginTop:"52px",
        right:32
      },dropdown1:{
        padding: "12px"
      },fullrangepicker:{
        marginTop: "18px"
      },leftpicker:{
        paddingLeft: "2px",
        paddingRight: "5px"
      }
      }));
      const classes = useStyles();
    return (
       <div> {props.Dropdowndefine===false?
        <div className={props.custombox===true?[classes.selectboxmain,classes.selectboxDesign].join(' '):[classes.selectboxmain,classes.selectboxDesign1,classes.selectboxDesign].join(' ')} >
        <Grid container  >
            <Grid className={classes.dropdown1}item xs={props.custombox===true?3:6}>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last1Min' value={0}> {t("Last 1 Min")} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last5Min' value={1}> {t("Last 5 Min")} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last15Min' value={2}> {t("Last 15 Min")} </IOTMenuItem>
                <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last30Min' value={3}> {t("Last 30 Min")} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last1Hour' value={4}> {t("LastHour")} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last3Hours' value={12}>{t('Last 3 Hrs')} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last6Hours' value={5}> {t("Last 6 Hrs")} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-today' value={6}> {t('Today')} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last24Hours' value={13}>{t('Last 24 Hrs')} </IOTMenuItem>
                
                  </Grid>
                  <Grid className={classes.dropdown1} item xs={props.custombox===true?3:6}>  
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-thisShift' value={11}> {t('ThisShift')} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox}onClick={(e)=>clickedGroupButton(e)} id='dashboard-yesterday' value={7}> {t('Yesterday')} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last7days' value={14}>{t('Last 7 Days')} </IOTMenuItem>                
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-thisWeek' value={8}> {t('ThisWeek')} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last30Days' value={15}>{t('Last 30 Days')} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-thisMonth' value={9}> {t('ThisMonth')} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)}id='dashboard-lastMonth' value={16}>{t('LastMonth')} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox}  style={props.custombox===true?{backgroundColor: "rgba(0, 0, 0, 0.04)"}:{}}  onClick={(e)=>clickedGroupButton(e)}id='dashboard-lastMonth' value={17}>{t('Custom')} </IOTMenuItem>
            </Grid>
            {props.custombox===true?<Grid item xs={6} >  
                   <Grid container  className={classes.fullrangepicker}>
                    <Grid item xs={6} >               
                    <Starttime getProps={props} />
                   </Grid>
                   <Grid item xs={6} className={classes.leftpicker}> 
                  <Endtime getProps={props} />
                     </Grid>
                     </Grid>
                     </Grid>:''}
            </Grid></div>:props.Dropdowndefine==="Explorer"?
            <div className={props.custombox===true?[classes.selectboxmain,classes.selectboxexp1].join(' '):[classes.selectboxmain,classes.selectboxexp2].join(' ')} >
             <Grid container  >
              <Grid className={classes.dropdown1} item xs={props.custombox===true?2:6}>
                  <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-lastHour' value={1}>{t('LastHour')}</MenuItem>
                  <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-last3Hours' value={12}>{t('Last 3 Hrs')} </MenuItem>
                <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-today' value={6}>{t('Today')} </MenuItem>
                 <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-last24Hours' value={18}>{t('Last 24 Hrs')} </MenuItem>
                 <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-thisshift' value={13}>{t('ThisShift')}  </MenuItem>
                  <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-yesterday' value={7}>{t('Yesterday')} </MenuItem>
                  </Grid>
                  <Grid className={classes.dropdown1} item xs={props.custombox===true?2:6}>                  
                    <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-last7days' value={14}>{t('Last 7 Days')} </MenuItem>
                    <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-thisWeek' value={8}>{t('This Week')}  </MenuItem>
                    <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)}  id='explore-thisMonth' value={9}>{t('ThisMonth')} </MenuItem>
                    <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-last30Days' value={15}>{t('Last 30 Days')} </MenuItem>
                    <MenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='explore-lastMonth' value={16}>{t('LastMonth')} </MenuItem>
                    <MenuItem  className={classes.slectbtnbox} style={props.custombox===true?{backgroundColor: "rgba(0, 0, 0, 0.04)"}:{}}  onClick={(e)=>clickedGroupButton(e)}id='dashboard-lastMonth' value={17}>{t('Custom')}  </MenuItem>
            </Grid>
            {props.custombox===true?<Grid item xs={8} >  
                   <Grid container className={classes.fullrangepicker} >
                    <Grid item xs={6} >              
                    <Starttime getProps={props} />
                   </Grid>
                   <Grid item xs={6} className={classes.leftpicker}> 
                   <Endtime getProps={props} />
                     </Grid>
                     </Grid>
                     </Grid>:''}
             </Grid></div>:props.Dropdowndefine==="Reports"?
             <div className={props.custombox===true?[classes.selectboxmain,classes.slectboxreport1].join(' '):[classes.selectboxmain,classes.slectboxreport2].join(' ')} >
             <Grid container  >
              <Grid className={classes.dropdown1} item xs={props.custombox===true?3:6}>
              <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last1Min' value={0}> {t("Last 1 Min")} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last5Min' value={1}> {t("Last 5 Min")} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last15Min' value={2}> {t("Last 15 Min")} </IOTMenuItem>
                <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last30Min' value={3}> {t("Last 30 Min")} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last1Hour' value={4}> {t("LastHour")} </IOTMenuItem>
                 <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last3Hours' value={12}>{t('Last 3 Hrs')} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last6Hours' value={5}> {t("Last 6 Hrs")} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-today' value={6}> {t('Today')} </IOTMenuItem>
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last24Hours' value={13}>{t('Last 24 Hrs')} </IOTMenuItem>
                  
                  </Grid>
                  <Grid className={classes.dropdown1} item xs={props.custombox===true?3:6}>   
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-thisShift' value={11}> {t('ThisShift')} </IOTMenuItem>
                    <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-yesterday' value={7}> {t('Yesterday')} </IOTMenuItem>
                   <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last7days' value={14}>{t('Last 7 Days')} </IOTMenuItem>               
                  <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-thisWeek' value={8}> {t('ThisWeek')} </IOTMenuItem>
                    <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-last30Days' value={15}>{t('Last 30 Days')} </IOTMenuItem>
                    <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)} id='dashboard-thisMonth' value={9}> {t('ThisMonth')} </IOTMenuItem>
                    <IOTMenuItem className={classes.slectbtnbox} onClick={(e)=>clickedGroupButton(e)}id='dashboard-lastMonth' value={16}>{t('LastMonth')} </IOTMenuItem>
                    <IOTMenuItem className={classes.slectbtnbox} style={props.custombox===true?{backgroundColor: "rgba(0, 0, 0, 0.04)"}:{}}  onClick={(e)=>clickedGroupButton(e)}id='dashboard-lastMonth' value={17}>{t('Custom')} </IOTMenuItem>
            </Grid>
            {props.custombox===true?<Grid item xs={6} >  
                   <Grid container  className={classes.fullrangepicker}>
                    <Grid item xs={6} style={{paddingLeft: "10px"}}>              
                    <Starttime getProps={props} />
                   </Grid>
                   <Grid item xs={6} className={classes.leftpicker}> 
                   <Endtime getProps={props} />
                     </Grid>
                     </Grid>
                     </Grid>:''}
                </Grid></div>:props.Dropdowndefine==="FromDate"?<Starttime getProps={props} />:props.Dropdowndefine==="EndDate"?<Endtime getProps={props} />:
                <div className={[classes.selectboxmain,classes.slectboxall].join(' ')}   >
                  <Grid container >  <Grid  >
                <Grid item xs={12}>
                    <IOTMenuItem onClick={(e)=>clickedGroupButton(e)} value={10}> {t('Current Job')} </IOTMenuItem>
                    <IOTMenuItem onClick={(e)=>clickedGroupButton(e)} value={11}> {t('ThisShift')} </IOTMenuItem>
                    <IOTMenuItem onClick={(e)=>clickedGroupButton(e)} value={6}> {t('Today')} </IOTMenuItem>
                    <IOTMenuItem onClick={(e)=>clickedGroupButton(e)} value={7}> {t('Yesterday')} </IOTMenuItem>
                   {/* <IOTMenuItem  style={props.custombox===true?{backgroundColor: "rgba(0, 0, 0, 0.04)"}:{}}  onClick={(e)=>clickedGroupButton(e)}id='dashboard-lastMonth' value={17}>Custom </IOTMenuItem> */}
                   </Grid>                  
                  </Grid></Grid></div>}</div>

    )
}