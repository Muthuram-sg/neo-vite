import React, { useState} from "react";
import { MuiPickersUtilsProvider,KeyboardDateTimePicker,KeyboardDatePicker,KeyboardTimePicker} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';

export default function Dashboard(props) {
  const [selectedDateEnd, setSelectedDateEnd] = useState(props.getProps.selectedtimeend);
  const handleDateChangeEnd = (date) => {
    setSelectedDateEnd(date);
    props.getProps.selectedendtime(date)
    }; 

    return (
        <>         
         <MuiPickersUtilsProvider utils={DateFnsUtils}> 
         {props.getProps.type==="OnlyDate"?<KeyboardDatePicker
        variant="inline"
        ampm={props.getProps.setAmPm}
        label={props.getProps.labelEt}
        value={selectedDateEnd}
        onChange={handleDateChangeEnd}
        onError={console.log}
        maxDate={new Date()}
        format={props.getProps.formats}
        KeyboardButtonProps={{
          'aria-label': 'change time',
        }}
      />:props.getProps.type==="OnlyTime"?<KeyboardTimePicker
      
      id="time-picker"
      ampm={props.getProps.setAmPm}
      label={props.getProps.labelEt}
      value={selectedDateEnd}
      onChange={handleDateChangeEnd}
      onError={console.log}
      //minDate={props.getProps.selectedtimestart}
       //maxDate={props.getProps.maxdate}
      format={props.getProps.formats}
      margin="normal"
      KeyboardButtonProps={{
        'aria-label': 'change time',
      }}
    />:<KeyboardDateTimePicker
      variant="inline"
      ampm={props.getProps.setAmPm}
      label={props.getProps.labelEt}
      value={selectedDateEnd}
      onChange={handleDateChangeEnd}
      onError={console.log}
      minDate={props.getProps.selectedtimestart}
       maxDate={new Date()}
      format={props.getProps.formats}
      KeyboardButtonProps={{
        'aria-label': 'change time',
      }}
    />}       
        </MuiPickersUtilsProvider>
        </>
    )
}