import React, { useState} from "react";
import { MuiPickersUtilsProvider,KeyboardDateTimePicker,KeyboardDatePicker,KeyboardTimePicker} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';

export default function Dashboard(props) {
  const [selectedDateStart, setSelectedDateStart] = useState(props.getProps.selectedtimestart);
  const handleDateChangeStart = (date) => {
    props.getProps.selectedstarttime(date)
   setSelectedDateStart(date);    
  };

    return (
        <>         
        <MuiPickersUtilsProvider utils={DateFnsUtils}>    
        {props.getProps.type==="OnlyDate"?<KeyboardDatePicker
        variant="inline"
        ampm={props.getProps.setAmPm}
        label={props.getProps.labelSt}
        value={selectedDateStart}
        onChange={handleDateChangeStart}
        onError={console.log}
        maxDate={new Date()}
        format={props.getProps.formats}
        KeyboardButtonProps={{
          'aria-label': 'change time',
        }}
      />:props.getProps.type==="OnlyTime"?<KeyboardTimePicker
       
        ampm={props.getProps.setAmPm}
        label={props.getProps.labelSt}
        value={selectedDateStart}
        onChange={handleDateChangeStart}
        onError={console.log}
        maxDate={props.getProps.maxdate}
        format={props.getProps.formats}
        KeyboardButtonProps={{
          'aria-label': 'change time',
        }}
    />:<KeyboardDateTimePicker
        variant="inline"
        id="time-picker"
        ampm={props.getProps.setAmPm}
        label={props.getProps.labelSt}
        value={selectedDateStart}
        onChange={handleDateChangeStart}
        onError={console.log}
        maxDate={new Date()}
        format={props.getProps.formats}
        KeyboardButtonProps={{
          'aria-label': 'change time',
        }}
    />}
         </MuiPickersUtilsProvider>
        </>
    )
}