import React from "react";
import { makeStyles } from '@material-ui/core/styles';
import SvgIcon from '@material-ui/core/SvgIcon';
import { ReactComponent as Plus } from 'assets/neo_icons/Menu/plus_icon.svg';
import { ReactComponent as ImageIcon } from 'assets/neo_icons/Menu/Image_icon.svg';
import { ReactComponent as CloseIcon } from 'assets/neo_icons/Menu/Close_Icon.svg';
import { useTranslation } from 'react-i18next';
import { ReactComponent as FileIcon } from 'assets/neo_icons/Menu/File_icon.svg';
export default function Dashboard(props) {
    const { t } = useTranslation();
    const useStyles = makeStyles((theme) => ({
        imageField: {
            border: '2px dashed rgba(0, 0, 0, 0.12)',
            borderRadius: '4px',
            margin: '10px',
            textAlign: 'center',
            padding: '10px'
        }, filesTypography: {
            display: 'inline-flex',
            border: '1px solid gainsboro',
            borderRadius: '4px',
            marginRight: '10px'
        }, filesName: {
            paddingLeft: '5px',
            paddingRight: '5px',
            fontSize: '14px',
            display: 'block',
            maxWidth: '130px',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            overflow: 'hidden'
        }, fileRemoveIcon: {
            verticalAlign: '-webkit-baseline-middle',
            width: '17px',
            cursor: 'pointer',
            marginTop: '3px'
        }, filecss: {
            backgroundColor: 'transparent',
            color: '#fcfcfc',
            width: '100%',
            left: '0',
            opacity: 0
        }, nofile: {
            marginTop: "-94px",
            height: '100px'
        }, typograpyCust: {
            fontSize: 14,
            marginTop: 10,
            fontWeight: 600
        }, typocust2: {
            fontSize: '16px',
            fontWeight: '500',
            marginTop: 10,
        }, taskUpload: {
            position: "absolute",
            width: "100%",
            height: "20vh",
            opacity: "0"
        }, taskupload2: {
            position: "relative"
        }
    }));
    const handleChangefn = (e) => {
        props.handleChange(e)
    }
    const removeFiles = (i, e) => {
        props.removeFilesfn(i, e)
    }
    const removeExistingFiles = (i, e) => {
        props.removeExistingFilesfn(i, e)
    }
    const classes = useStyles();
    return (

        <div className={[classes.taskupload2, classes.imageField].join(' ')}>
            <input id="file-input" className={classes.taskUpload} multiple={props.multiple} type="file" ref={props.dropzoneRef} onChange={(e) => handleChangefn(e)} />
            <div >
                {
                    props.filesArrs && props.filesArrs.length < props.fileLength ? (
                        <label for="file-input"  >

                            <div>
                                <SvgIcon fontSize="small"><Plus /></SvgIcon>
                            </div>
                        </label>
                    ) : (<></>)
                }
                {
                    props.filesArrs && props.filesArrs.length > 0 ? (
                        <div style={{ display: 'inline-flex' }}>
                            {
                                props.filesArrs.map((val, index) => {
                                    return (<span className={[classes.filesTypography, classes.typograpyCust].join(' ')}>
                                        <SvgIcon style={{ verticalAlign: "middle" }}>
                                            {
                                                val.type ? (val.type.split('/')[0] === 'image' ? (<ImageIcon stroke={'#0084FF'} />) : (<FileIcon stroke={'#0084FF'} />)
                                                ) : val.image_path.split('.')[1] == 'jpeg' || val.image_path.split('.')[1] == 'jpg' || val.image_path.split('.')[1] == 'png' ? (<ImageIcon stroke={'#0084FF'} />) : (<FileIcon stroke={'#0084FF'} />)
                                            }

                                        </SvgIcon>
                                        <span className={classes.filesName}>{val.name ? val.name : val.image_path}</span>
                                        <SvgIcon className={classes.fileRemoveIcon} onClick={(e) => val.type ? removeFiles(index, e) : removeExistingFiles(index, val)}>
                                            <CloseIcon stroke={'#0084FF'} />
                                        </SvgIcon>
                                    </span>)
                                })
                            }
                        </div>
                    ) : (
                        <>
                            <span className={classes.typocust2} variant="body2" >{t(props.Dropdowntext)}</span><br />
                            <span className={classes.typocust2} variant="caption" >{t(props.fileformat)}</span><br />
                            <span className={classes.typocust2} variant="caption" >{t(props.maxsize)}</span>
                        </>
                    )
                }

                {/*  accept="image/jpg, image/jpeg" */}

            </div>
        </div>

    )
}