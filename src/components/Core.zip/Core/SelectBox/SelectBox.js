import React  from "react";
import { TextField } from "@mui/material";
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import Autocomplete  from '@material-ui/lab/Autocomplete';
import Checkbox from '@material-ui/core/Checkbox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import { makeStyles } from "@material-ui/core/styles";
import {  FormHelperText } from "@material-ui/core";
import ParagraphText from "../Typography/Typography";
import { useTranslation } from 'react-i18next';

const SelectBox =  React.forwardRef((props,ref)=>{
 
  const { t } = useTranslation();
  const useStyles = makeStyles(() => ({
    root: {
      width: "100%",
      padding: "1px",
      borderRadius: "4px",
      '& .MuiSelect-outlined':{
        padding: '10px'
      },
      '& .MuiAutocomplete-inputRoot':{
        padding: '10px'
      },
     
    },
    
    iconbutton: {
      float: 'right',
      marginRight: 10,
      boxShadow: 'none',
      backgroundColor: 'transparent',
      height:"24px",
      width:"24px",
    },
    selectContainer:{
      display:"flex"
    },
    


  }));

  const classes = useStyles();  
    const SelectedValues = props.value;
    const [value, setValue] = React.useState(props.edit?SelectedValues:[]);
    const [isBtnActive, setIsBtnActive] = React.useState(false);
    const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
    const checkedIcon = <CheckBoxIcon fontSize="small" />;
      return (
        !props.auto?
        <React.Fragment>
          <ParagraphText variant="Body2" value={props.label}/>
          <div className={classes.selectContainer}>
        <Select
          labelId={props.labelId}
          id={props.id}
          multiple={props.multiple ? props.multiple:false}
          ref={props.inputRef}
          onChange={props.onChange}
          fullWidth
          error={props.error ? props.error:false }
          disabled={props.disabled ? props.disabled:false}
          className={classes.root}
          value={props.value?props.value:[]}
          
         // label={props.label}
        >
          {
            props.defaultDisableOption &&(
              <MenuItem 
              id={'select-' + props.defaultDisableName? props.defaultDisableName:''} 
              disabled value=""
               key={-1}>{t('Select') + props.defaultDisableName? props.defaultDisableName:''}
               </MenuItem>
            )
        }
          
            {
                props.options  &&
                props.options.map((data)=>{
                   
                    return(
                    <MenuItem 
                    key={props.isMArray && props.isMArray?props.keyId?data[props.keyId]:'':data} 
                    id={props.isMArray && props.isMArray?props.keyId?data[props.keyId]:'':data}  
                    value={props.isMArray && props.isMArray?props.keyId?data[props.keyId]:'':data}>
                      {props.isMArray && props.isMArray?props.keyValue?data[props.keyValue]:'':data}
                      </MenuItem>
                    )
                })
            }
        </Select>
        {props.isBtnActive&& props.btnProps ? (
          props.btnProps
        ):null}
        
      </div>
        {
        props.error ? 
        <FormHelperText style={{ color: "#FF0D00" }}>{props.msg}</FormHelperText> 
        : 
        null
        }
        </React.Fragment>
        :
        props.edit?(
          <React.Fragment>
            <ParagraphText variant="Body2" value={props.label}/>
          <div className={classes.selectContainer}>
        <Autocomplete
        open={props.open}
        onOpen={props.onOpen}
        onClose={props.onClose}
        id={props.id}
        options={props.options}
        placeholder={props.placeholder}
        fullWidth
        disableCloseOnSelect={true}
        //label={props.label}
        defaultValue={
          !props.multiple  ?
            (props.value && props.value[0]) ?
            props.value[0]:
            []
          :
            props.value ? 
              props.value
              :
              []
        }
        className={classes.root}
        error={props.error ? props.error:false }
        getOptionSelected={(option, SelectedValues) => {
          
          return  option[props.keyValue] === SelectedValues[props.keyValue]
        }}
       
        renderOption={(option, { selected }) => (
         
            <React.Fragment>
              
                {props.checkbox && 
                <Checkbox
                icon={icon}
                checkedIcon={checkedIcon}
                style={{ marginRight: 8 }}
                checked={selected}
                color={"primary"}
                
              />
                }
                
              
              {props.isMArray? option[props.keyValue]:option}
            </React.Fragment>
          )

        }
          ref={ref}
          getOptionLabel={(option) => 
           
            props.isMArray?props.keyValue?option[props.keyValue]:"":option
            
          }
          //getOptionLabel={(option) => props.isMArray?props.keyValue?option:"":option}
        multiple={props.multiple}
        renderInput={(params) => 
        <TextField {...params} value={value} 
        inputRef={props.inputref} 
        onChange={(e)=>{
          let filter = props.options.filter(x=> x.title.toLowerCase().includes(e.target.value.toLowerCase()))
       
            if(filter.length > 0){
              setIsBtnActive(false)
            }else{
              setIsBtnActive(true)
            }
          setValue(e.target.value)
        }} 
        variant="outlined" />
      }
        onChange={props.onChange}
        disabled={props.disabled?props.disabled:false}
        
      />
       {isBtnActive && props.btnProps ? (
          props.btnProps
        ):null}
      </div>
      {props.error ? <FormHelperText  style={{ color: "#FF0D00" }}>{props.msg}</FormHelperText> : null}
       </React.Fragment>
        ):(
          <React.Fragment>
            <ParagraphText variant="Body2" value={props.label}/>
          <div className={classes.selectContainer}>
        <Autocomplete
        id={props.id}
        options={props.options}
        placeholder={props.placeholder}
        fullWidth
        disableCloseOnSelect={true}
        defaultValue={
          !props.multiple?props.value && props.value[0]?
          props.value[0]
          :
          []
          :
          props.value?
          props.value
          :
          []}
        className={classes.root}
        error={props.error ? props.error:false }
        
        renderOption={(option, { selected }) => (
            <React.Fragment>
               
                {props.checkbox && 
                <Checkbox
                icon={icon}
                checkedIcon={checkedIcon}
                style={{ marginRight: 8 }}
                checked={selected}
                color={"primary"}
                
              />
                }
                
              
              {props.isMArray?option[props.keyValue]:option}
            </React.Fragment>
          )

        }
         
        getOptionLabel={(option) => 
          props.isMArray?
          props.keyValue?
          option[props.keyValue]
          :
          ""
          :
          option
        }
        multiple={props.multiple}
        renderInput={(params) => 
        <TextField {...params} value={value}
        inputRef={props.inputref} 
         onChange={(e)=>{
          let filter = props.options.filter(x=> x.title.toLowerCase().includes(e.target.value.toLowerCase()))
       
            if(filter.length > 0){
              setIsBtnActive(false)
            }else{
              setIsBtnActive(true)
            }
          setValue(e.target.value)
        }}  />
      }
        onChange={props.onChange}
        onInputChange={props.onInputChange}
        disabled={props.disabled?props.disabled:false}
        
      />
       {isBtnActive && props.btnProps ? (
          props.btnProps
        ):null}
      </div>
      {props.error ? <FormHelperText style={{ color: "#FF0D00" }}>{props.msg}</FormHelperText> : null}
       </React.Fragment>
        )
        
        );
});
// export default SelectBox;
const isRender = (prev,next)=>{ 
    return prev.value !== next.value  || 
    prev.disabled !== next.disabled || 
    prev.error !== next.error || 
    prev.options !== next.options || 
    prev.msg!== next.msg? false:true;
} 
export default React.memo(SelectBox,isRender);
