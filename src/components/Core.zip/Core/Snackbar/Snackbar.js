import React from "react";
import { Snackbar } from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';
import {Slide} from '@material-ui/core/'; 

export default function SnackBar(props) { 
    const vertical = "top";
    const horizontal = "center" 
    return (
    <Snackbar open={props.open ? props.open : false} anchorOrigin={{ vertical, horizontal }} key={2} TransitionComponent={Slide} autoHideDuration={6000} onClose={props.handleSnackClose}>
        <Alert onClose={props.handleSnackClose} severity={props.type ? props.type : ''}>
        {props.message ? props.message : ''} 
        </Alert>
    </Snackbar>
    
    );
} 