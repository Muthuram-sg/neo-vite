import React from "react";
import { TextField, InputAdornment } from "@material-ui/core";
import { makeStyles,useTheme } from "@material-ui/styles";
import ParagraphText from "../Typography/Typography";


const EnhancedTextField = React.forwardRef((props, ref) => {
    const useStyles = makeStyles((theme) => ({
        root: {
            width:"100%",
            padding: "1px",
            borderRadius: "4px",
            '& p': {
                background: theme.colorPalette.foreGround,
                color: props.error ? props.disabled ? theme.colorPalette.disabled : theme.colorPalette.genericRed :theme.palette.secondaryText.main,
                marginLeft : 0,
                fontWeight:500,
                fontSize:"12px",
                fontFamily:"Inter",
                
            },
            "& .MuiInputBase-root": {
                background: theme.palette.background.default,
                "& fieldset":{
                    border : props.error ? "2px solid "+theme.colorPalette.genericRed : 0,                    
                    
                },
               
            }, 
            "& .MuiOutlinedInput-root.Mui-focused fieldset": {
                border: props.error ? "2px solid "+theme.colorPalette.genericRed :"2px solid "+theme.colorPalette.blue            
            },
            "& .MuiOutlinedInput-root.Mui-error .MuiOutlinedInput-notchedOutline": {
                borderColor: theme.colorPalette.genericRed 
              },
            "& .MuiOutlinedInput-input":{
                fontFamily: "Inter",
                fontSize: "16px",
                fontWeight: "400",
                color: theme.colorPalette.primary,
                paddingTop: '6px',
                paddingBottom: '6px',
    
            }  ,
            "& .MuiInputAdornment-positionStart":{
                marginRight : "2px",
                opacity : props.disabled ? 0.3 : 1
            },
            "& .MuiInputAdornment-positionEnd":{
                opacity : props.disabled ? 0.3 : 1
            },
            "& .MuiOutlinedInput-adornedStart":{
                paddingLeft : "5px"
            },
            "& .MuiOutlinedInput-adornedEnd":{
                paddingRight : "2px"
            },
            "& .MuiOutlinedInput-root.Mui-disabled":{
                background : theme.colorPalette.backGround
            }
        },
       
        
    }));

    const classes = useStyles();
    const theme = useTheme()

    return (
        <React.Fragment>
        {props.label && <ParagraphText value={props.label} color={props.disabled ? theme.colorPalette.disabled : theme.colorPalette.primary} variant={"Caption1"} ></ParagraphText>}
        <TextField
            id={props.id}
            defaultValue={props.defaultValue ? props.defaultValue : undefined}
            variant={"outlined"}
            type={props.type}
            size={props.size}
            placeholder={props.placeholder}
            error={props.error}
            inputRef={props.inputRef}
            helperText={props.helperText ? props.helperText : undefined}
            multiline={props.multiline ? props.multiline : undefined}
            maxRows={props.multiline ? props.maxRows : undefined}
            value={props.value}
            fullWidth
            autoFocus={props.autoFocus}
            onChange={props.onChange}
            className={classes.root}
            required={props.required ? props.required : false}
            disabled={props.disabled}
            onBlur={props.onBlur}
            InputProps={{
                startAdornment: <InputAdornment position="start" disablePointerEvents={props.disabled}> {props.startAdornment ? props.startAdornment : <React.Fragment></React.Fragment>} </InputAdornment>,
                endAdornment: <InputAdornment position="end" disablePointerEvents={props.disabled}>{props.endAdornment ? props.endAdornment :  <React.Fragment></React.Fragment>}</InputAdornment>,
                disableUnderline: props.disableUnderline
            }}
            

        />
        </React.Fragment>
    )
});
const isRender = (prev,next)=>{  
    return prev.value!==next.value  || prev.disabled !== next.disabled || prev.error !== next.error || prev.helperText !== next.helperText? false : true
}
const CustomTextField = React.memo(EnhancedTextField,isRender)
export default CustomTextField;
