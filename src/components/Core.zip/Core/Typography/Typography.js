import React from "react";
import { Typography } from "@material-ui/core/";
import { makeStyles } from "@material-ui/core/styles";

const  ParagraphText =(props) => {
    const useStyles = makeStyles((theme) => ({
        root: {
            fontFamily:'Inter, sans-serif',
            fontStyle: "normal",
            color : props.color
        },
        h1:{
            
            fontWeight: "600",
            fontSize: "40px",
            lineHeight: "64px",

        },
        h2:{
            fontWeight: 600,
            fontSize: "34px",
            lineHeight: "48px",
        },
        Sub1:{
            fontWeight: 600,
            fontSize: "28px",
            lineHeight: "40px",
        },
        Sub2:{
            fontWeight: 500,
            fontSize: '24px',
            lineHeight: '28px',
        },
        Body:{
            fontWeight: 500,
            fontSize: '20px',
            lineHeight: '24px',
        },
        Body1:{
            fontWeight: 500,
            fontSize: "20px",
            lineHeight: '24px',
        },
        Body2:{
            fontWeight: 500,
            fontsize: '16px',
            lineHeight: '24px',
        },
        Body2Reg:{
            fontWeight: 400,
            fontSize: '16px',
            lineHeight: '24px',
        },
        Caption1:{
            fontWeight: 500,
            fontSize: '14px',
            lineHeight: '24px',
        },
        Caption2:{
            fontWeight: 500,
            fontSize: '12px',
            lineHeight: '18px',
        },


      }));
      const classes = useStyles();      
    return(
        <Typography  
        align={props.align && props.align} 
        className={[
                    classes.root,props.variant==="h1" ? 
                    classes.h1 
                    :props.variant==="h2" ?
                    classes.h2:
                    props.variant==="Sub1" ?
                    classes.Sub1:
                    props.variant==="Sub2"?
                    classes.Sub2:
                    props.variant==="Body"?
                    classes.Body:
                    props.variant==="Body1"?
                    classes.Body1:
                    props.variant==="Body2"?
                    classes.Body2:
                    props.variant==="Body2Reg"?
                    classes.Body2Reg:
                    props.variant==="Caption1"?
                    classes.Caption1:
                    classes.Caption2

         ].join(' ')} 
        > {props.value}</Typography>
    );
}
const isRender = (prev,next)=>{ 
    return prev.value !== next.value ||
     prev.align !== next.align ||
      prev.variant !== next.variant ||
       prev.color !== next.color ? false:true;
} 
export default React.memo(ParagraphText,isRender);