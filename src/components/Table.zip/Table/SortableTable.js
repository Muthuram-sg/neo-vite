import React from "react";
import PropTypes from 'prop-types';
import { Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, TableSortLabel, Collapse, Grid,makeStyles } from '@material-ui/core';
import { useRecoilState } from "recoil";
import { themeMode } from "recoil/atoms";

function descendingComparator(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator(order, orderBy) {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

// This method is created for cross-browser compatibility, if you don't
// need to support IE11, you can use Array.prototype.sort() directly
function stableSort(array, comparator) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = comparator(a[0], b[0]);
    if (order !== 0) {
      return order;
    }
    return a[1] - b[1];
  });
  return stabilizedThis.map((el) => el[0]);
}




function EnhancedTableHead(props) {
  // eslint-disable-next-line no-unused-vars
  const { onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort } =
    props;
  const createSortHandler = (property) => (event) => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>

        {props.headCells.map((headCell, index) => (
          headCell.display !== "none" && <TableCell
            key={headCell.id}
            align={'center'}
            padding={headCell.disablePadding ? 'none' : 'normal'}
            sortDirection={orderBy === headCell.id ? order : false}

          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : 'asc'}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {/* {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                </Box>
              ) : null} */}
            </TableSortLabel>
          </TableCell>

        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(['asc', 'desc']).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

export default function EnhancedTable(props) {
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('name');
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10); 
  const [curTheme] = useRecoilState(themeMode);
  const useStyles = makeStyles((theme)=>({
    tableCell:{
      wordWrap: 'break-word',
      color: curTheme === 'dark'?theme.colorPalette.darkSecondary:theme.colorPalette.secondary
    }
  }))
  const classes = useStyles();
  const handlefinalrows = () => {
 
    if (page > 0) {
      return stableSort(props.rows, getComparator(order, orderBy)).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
    }
    else {

      return stableSort(props.rows, getComparator(order, orderBy)).slice(0 * rowsPerPage, 0 * rowsPerPage + rowsPerPage)
    }
  }

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };




  const handleChangePage = (event, newPage) => {
    //  console.log("page",page);
  //   if(props.search !=="" && page > 0){
  //     setPage(page+1);
  //   }else{
      setPage(newPage);
    // }
    
    

  };

  const handleChangeRowsPerPage = (event) => {

    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);

  };

  return (
    <>
      <TableContainer  >
        <Table
          aria-labelledby="tableTitle"
          size={'small'}
        //style={{ tableLayout: "fixed" }}
        >

          <EnhancedTableHead
            order={order}
            orderBy={orderBy}
            onRequestSort={handleRequestSort}
            rowCount={props.rows.length}
            headCells={props.headCells}
          />
          <TableBody>


            {
              // stableSort(props.rows, getComparator(order, orderBy))
              // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage) 
              handlefinalrows().map((row, index) => {

                const labelId = `enhanced-table-checkbox-${index}`;

                return (
                  
                    <TableRow >
                      {props.headCells.map((val, index) => {
                        if (index === 0) {
                          return val.display !== "none" && <TableCell
                            component="th"
                            id={labelId}
                            scope="row"
                            padding="none"
                            align='center'
                            className={classes.tableCell}
                          >
                            {Object.values(row)[0]}
                          </TableCell>
                        }
                        else {
                          return val.display !== "none" && <TableCell className={classes.tableCell} align={'center'}>{Object.values(row)[index]}</TableCell>
                        }


                      })}

                    </TableRow>
                  
                );
              })}
            {props.GetCollapsibleRow && <TableRow>
              <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={12}>
                <Collapse in={props.open} timeout="auto" unmountOnExit>
                  <Grid container spacing={1} style={{ paddingLeft: 20, marginBottom: 10 }}>
                    {props.GetCollapsibleRow()}
                  </Grid>
                </Collapse>
              </TableCell>
            </TableRow>}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[10, 20, 50, 100]}
        component="div"
        count={props.rows.length}
        rowsPerPage={rowsPerPage}
        page={page > 0 ? page : 0}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />
    </>

  );
}
