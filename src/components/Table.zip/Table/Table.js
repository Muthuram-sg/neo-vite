import { useEffect, useMemo, useState } from "react";
import React from "react";
import PropTypes from 'prop-types';
import { Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, TableSortLabel, Collapse, Grid, makeStyles } from '@material-ui/core';
import { useRecoilState } from "recoil";
import { themeMode } from "recoil/atoms";
import Button from "components/Core/Buttons/Button";
import { ReactComponent as Delete } from 'assets/neo_icons/Menu/ActionDelete.svg'
import { ReactComponent as Edit } from 'assets/neo_icons/Menu/ActionEdit.svg'
import TableSearch from "./TableSearch";
import TableDownload from "./TableDownload";
import CustomTableRow from "./TableRow";
import EnhancedTableHeader from "./TableHeader";



function descendingComparator(a, b, orderBy) {
    if (b[orderBy] < a[orderBy]) {
        return -1;
    }
    if (b[orderBy] > a[orderBy]) {
        return 1;
    }
    return 0;
}

function getComparator(order, orderBy) {
    return order === 'desc'
        ? (a, b) => descendingComparator(a, b, orderBy)
        : (a, b) => -descendingComparator(a, b, orderBy);
}

function stableSort(array, comparator) {
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) {
            return order;
        }
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}

function EnhancedTableHead(props) {
    // eslint-disable-next-line no-unused-vars
    const { onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort } =
      props;
    const createSortHandler = (property) => (event) => {
      onRequestSort(event, property);
    };
  
    return (
      <TableHead>
        <TableRow>
  
          {props.headCells.map((headCell, index) => (
            headCell.display !== "none" && <TableCell
              key={headCell.id}
              align={'center'}
              padding={headCell.disablePadding ? 'none' : 'normal'}
              sortDirection={orderBy === headCell.id ? order : false}
  
            >
              <TableSortLabel
                active={orderBy === headCell.id}
                direction={orderBy === headCell.id ? order : 'asc'}
                onClick={createSortHandler(headCell.id)}
              >
                {headCell.label}
                {/* {orderBy === headCell.id ? (
                  <Box component="span" sx={visuallyHidden}>
                    {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                  </Box>
                ) : null} */}
              </TableSortLabel>
            </TableCell>
  
          ))}
        </TableRow>
      </TableHead>
    );
  }
  
  EnhancedTableHead.propTypes = {
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired,
  };

function CustomTable(props) {
    const [order, setOrder] = React.useState('asc');
    const [orderBy, setOrderBy] = useState('name');
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [curTheme] = useRecoilState(themeMode);
    const [search, setSearch] = useState("")
    const [completetabledata, setCompleteTableData] = useState([])
    const [visibleheadCells, setvisibleheadCells] = useState(props.headCells)

    var visibledata = [...props.data]

    const useStyles = makeStyles((theme) => ({
        tableCell: {
            wordWrap: 'break-word',
            color: curTheme === 'dark' ? theme.colorPalette.darkSecondary : theme.colorPalette.secondary
        },
        actionIcon: theme.actionIcons
    }))
    const classes = useStyles();





    const createrows = () => {
        const keys = props.headCells.map((key) => key.id)
        var rows = []
        if (props.data.length > 0) {
            rows = [].concat(props.data.map((val, index) => {
                var obj = {}
                keys.forEach((k, i) => obj[k] = val[i])
                return obj
            })
            )
        }


        return rows
    }

    useEffect(() => {
        setCompleteTableData(createrows())
        if (props.actionenabled) {
            visibledata.forEach((row, index) => { row.push(renderActionButton(props.rawdata[index], index)) })

        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.data])
    useEffect(() => {
        if (props.actionenabled) {
            var tempheadCells = [...visibleheadCells]
            tempheadCells.push(
                {
                    id: 'actions',
                    numeric: false,
                    disablePadding: false,
                    label: 'Actions',
                }
            )
            setvisibleheadCells(tempheadCells)


        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [props.actionenabled])
    const calculateData = (data, search) => {
        let filData = []
        if (search !== '') {
            //filData = data.filter((item) => item.name.toLowerCase().includes(search.toLowerCase()) || item.id.toLowerCase().includes(search.toLowerCase()))
            filData = data.filter((item) => {
                let values = Object.values(item)
                return values.some(function (val) {
                    return String(val).toLowerCase().includes(search.toLowerCase())
                })
            })
            return filData
        }
        else {

            return data

        }
    }

    // eslint-disable-next-line react-hooks/exhaustive-deps
    const currentTableData = useMemo(() => calculateData(props.data, search), [props.data, search]);

    const renderActionButton = (value, id) => {


        return (
            <React.Fragment>
                <Edit className={classes.actionIcon} id={'edit-instrument-' + value}
                    onClick={() => {
                        try {
                            props.handleEdit(id, value)
                        } catch (err) {
                            console.log("err", err)
                        }
                    }} />
                <Delete
                    className={classes.actionIcon} id={'delete-instrument-' + value}
                    onClick={() => {

                        try {
                            props.handleDelete(id, value)
                        } catch (err) {
                            console.log("err", err)
                        }
                    }} />
            </React.Fragment>
        )

    }
    const handlefinalrows = () => {

        if (page > 0) {
            // console.log(stableSort(currentTableData, getComparator(order, orderBy)).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage))
            return stableSort(currentTableData, getComparator(order, orderBy)).slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
        }
        else {
            // console.log("order,orderby", order, orderBy, stableSort(currentTableData, getComparator(order, orderBy)).slice(0 * rowsPerPage, 0 * rowsPerPage + rowsPerPage))
            return stableSort(currentTableData, getComparator(order, orderBy)).slice(0 * rowsPerPage, 0 * rowsPerPage + rowsPerPage)
        }
    }

    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };




    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {

        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);

    };

    // console.log("visibleheadcells", visibleheadCells)
    return (
        <div>
            <div style={{ display: 'flex', float: "right" }}>
                <TableSearch searchdata={(value) => { setSearch(value) }} />
                <TableDownload data={completetabledata} />
                {/* <Button type="ghost" icon={Download} onClick={()=>downloadExcel(currentTableData, "Info")}></Button> */}
                {props.buttonpresent &&
                    <div style={{ marginLeft: 10, marginBottom: 10, float: 'right' }}>
                        <Button type={"tertiary"} value={props.buttonvalue} onClick={props.onClickbutton}></Button>
                    </div>
                }
            </div>
            <TableContainer  >
                <Table
                    aria-labelledby="tableTitle"
                    size={'small'}
                >
                    <EnhancedTableHeader
                        order={order}
                        orderBy={orderBy}
                        onRequestSort={handleRequestSort}
                        rowCount={currentTableData.length}
                        headCells={visibleheadCells}
                    />
                    <TableBody>
                        {
                            handlefinalrows().map((row, index) => {
                                return (<CustomTableRow row={row} index={index} headCells={visibleheadCells}/>)
                            })}
                        {props.GetCollapsibleRow && <TableRow>
                            <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={12}>
                                <Collapse in={props.open} timeout="auto" unmountOnExit>
                                    <Grid container spacing={1} style={{ paddingLeft: 20, marginBottom: 10 }}>
                                        {props.GetCollapsibleRow()}
                                    </Grid>
                                </Collapse>
                            </TableCell>
                        </TableRow>}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[10, 20, 50, 100]}
                component="div"
                count={currentTableData.length}
                rowsPerPage={rowsPerPage}
                page={page > 0 ? page : 0}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
        </div >

    );
}
const isRender = (prev, next) => {
    return prev.data !== next.data ? false : true
}
const EnhancedTable = React.memo(CustomTable, isRender)
export default EnhancedTable
