import React from "react";
import Button from "components/Core/Buttons/Button"
import { ReactComponent as Download } from 'assets/neo_icons/Menu/DownloadSimple.svg'
const XLSX = require("xlsx")

function DataDownload(props){
const downloadExcel = (data, name) => {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    XLSX.writeFile(workbook, name + ".xlsx");
};
return <Button type="ghost" icon={Download} onClick={()=>downloadExcel(props.data, "Info")}></Button>
}
const isRender = (prev,next)=>{  
    return prev.data !== next.data  ? false:true;
}
const TableDownload = React.memo(DataDownload,isRender)
export default TableDownload