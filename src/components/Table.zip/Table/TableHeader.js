
import React from "react";
import PropTypes from 'prop-types';
import {  TableCell, TableHead, TableRow, TableSortLabel } from '@material-ui/core';

function CustomTableHeader(props) {
    // eslint-disable-next-line no-unused-vars
    const { onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort } =
        props;
    const createSortHandler = (property) => (event) => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow>

                {props.headCells.map((headCell, index) => (
                    headCell.display !== "none" && <TableCell
                        key={headCell.id}
                        align={'center'}
                        padding={headCell.disablePadding ? 'none' : 'normal'}
                        sortDirection={orderBy === headCell.id ? order : false}

                    >
                        <TableSortLabel
                            active={orderBy === headCell.id}
                            direction={orderBy === headCell.id ? order : 'asc'}
                            onClick={createSortHandler(headCell.id)}
                        >
                            {headCell.label}
                        </TableSortLabel>
                    </TableCell>

                ))}
            </TableRow>
        </TableHead>
    );
}

CustomTableHeader.propTypes = {
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired,
};
const isRender = (prev, next) => {
    return prev.headCells !== next.headCells || prev.order !== next.order || prev.orderBy !== next.orderBy ?  false : true
}
const EnhancedTableHeader = React.memo(CustomTableHeader, isRender)

export default EnhancedTableHeader
