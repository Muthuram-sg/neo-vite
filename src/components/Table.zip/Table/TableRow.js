
import React from "react";
import {  TableCell, TableRow, makeStyles } from '@material-ui/core';
import { useRecoilState } from "recoil";
import { themeMode } from "recoil/atoms";



function CustomTableRow(props) {
    
    const [curTheme] = useRecoilState(themeMode);

    const useStyles = makeStyles((theme) => ({
        tableCell: {
            wordWrap: 'break-word',
            color: curTheme === 'dark' ? theme.colorPalette.darkSecondary : theme.colorPalette.secondary
        },
        actionIcon: theme.actionIcons
    }))
    const classes = useStyles();



    return (
        
        <TableRow >
            
            {props.headCells.map((val, index) => {
               
                if (index === 0) {
                    return val.display !== "none" && <TableCell
                        component="th"
                        id={`enhanced-table-checkbox-${props.index}`}
                        scope="row"
                        padding="none"
                        align='center'
                        className={classes.tableCell}
                    >
                        {Object.values(props.row)[0]}
                    </TableCell>
                }
                else {
                    return val.display !== "none" && <TableCell className={classes.tableCell} align={'center'}>{Object.values(props.row)[index]}</TableCell>
                }


            })}

        </TableRow>
    
    



    )}

export default CustomTableRow
