
import { React,useState } from "react";
import { ClickAwayListener } from "@material-ui/core"
import CustomTextField from "components/Core/TextField/TextField"
import { ReactComponent as Search } from 'assets/neo_icons/Menu/SearchTable.svg'
import { ReactComponent as Clear } from 'assets/neo_icons/Menu/ClearSearch.svg';
import Button from "components/Core/Buttons/Button";
export default function TableSearch(props){
    const [search, setSearch] = useState("");
    const [input, setInput] = useState(false);

    const updateSearch = (event) => {
        setSearch(event.target.value);
        props.searchdata(event.target.value)
        // calculateData(currentPage, InstrumentFormulaList, event.target.value)
    }

    const clickAwaySearch = () => {
        if (search === '')
          setInput(false)
        else
          setInput(true)
      }
    

    return (
        <ClickAwayListener onClickAway={clickAwaySearch}>
            {input ? <div><CustomTextField
                placeholder="Search"
                size="small"
                value={search}
                type="text"
                onChange={updateSearch}
                disableUnderline={true}
                startAdornment={<Search style={{ cursor: "pointer", padding: '4px', stroke: "black" }} />}
                endAdornment={props.search !== '' ? <Clear onClick={() => { setSearch('');props.searchdata('') }} style={{ cursor: "pointer" }} /> : <React.Fragment></React.Fragment>}
                autoFocus
            /></div> : <Button type={"ghost"} icon={Search} onClick={() => { setInput(true) }} />}
        </ClickAwayListener>
            )
 }